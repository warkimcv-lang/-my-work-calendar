MY WORK CALENDAR — PWA

Isi paket:
- index.html              aplikasi utama
- manifest.webmanifest    identitas PWA
- sw.js                   offline/service worker
- icons/                  ikon aplikasi

CARA MEMASANG DI iPHONE
1. Upload seluruh isi folder ini ke hosting HTTPS, misalnya GitHub Pages, Netlify, atau Vercel.
2. Buka alamat HTTPS aplikasi menggunakan Safari di iPhone.
3. Tekan Share.
4. Pilih "Add to Home Screen" / "Tambahkan ke Layar Utama".
5. Tekan Add.
6. Buka ikon My Work Calendar dari Home Screen.

CATATAN
- PWA/service worker membutuhkan HTTPS (localhost juga bisa untuk pengembangan).
- Data absensi disimpan di localStorage pada browser/perangkat.
- Gunakan tombol Export semua data untuk membuat backup JSON.
